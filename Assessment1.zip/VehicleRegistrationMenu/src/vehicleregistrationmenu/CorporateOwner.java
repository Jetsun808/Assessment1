/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vehicleregistrationmenu;

/**
 *
 * @author Jetsu
 */
public class CorporateOwner extends Owner {

    private int ABN;

    /**
     * Constructor
     *
     * @param n
     * @param add
     * @param phn
     * @param abn
     */
    public CorporateOwner(String n, String add, String phn, int abn) {
        // Call the superclass constructor,
        // passing the name,address and phoneNumber as arguments.
        super(n, add, phn);

        // Set ABN.
        this.ABN = abn;
    }
    //mutator

    public void setABN(int abn) {
        this.ABN = abn;
    }

    //accessor 
    public int getABN() {
        return ABN;
    }
}
