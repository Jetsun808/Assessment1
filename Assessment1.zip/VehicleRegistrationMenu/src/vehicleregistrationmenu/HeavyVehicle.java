/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vehicleregistrationmenu;

/**
 *
 * @author Jetsu
 */
public class HeavyVehicle extends Vehicle {

    private int loadCapacity;

    public HeavyVehicle(String pln, String mk, String m, int y, boolean isp, int oid, int oab, int lc) {
        // Call the superclass constructor,
        // passing the plateNumber, make, model, year, isPrivate, ownerId and ownerABN as arguments.
        super(pln, mk, m, y, isp, oid, oab);

        // Set ABN.
        this.loadCapacity = lc;
    }
//mutator

    public void setLoadCapacity(int lc) {
        this.loadCapacity = lc;
    }
//accessor

    public int getLoadCapacity() {
        return loadCapacity;
    }
}
