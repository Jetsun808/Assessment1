/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vehicleregistrationmenu;

/**
 *
 * @author Jetsu
 */
public class LightVehicle extends Vehicle {

    private int numberofSeats;

    public LightVehicle(String pln, String mk, String m, int y, boolean isp, int oid, int oab, int nbs) {
        // Call the superclass constructor,
        // passing the plateNumber, make, model, year, isPrivate, ownerId and ownerABN as arguments.
        super(pln, mk, m, y, isp, oid, oab);

        // Set ABN.
        this.numberofSeats = nbs;
    }
//mutator

    public void setNumberofSeats(int nbs) {
        this.numberofSeats = nbs;
    }
//accessor

    public int getNumberofSeats() {
        return numberofSeats;
    }
}
