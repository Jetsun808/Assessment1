/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vehicleregistrationmenu;

/**
 *
 * @author Jetsu
 */
public class Owner {

    private String name;
    private String address;
    private String phoneNumber;

    /**
     * Constructor
     *
     * @param n
     * @param add
     * @param phn
     */
    public Owner(String n, String add, String phn) {
        this.name = n;
        this.address = add;
        this.phoneNumber = phn;
    }

    //mutator
    public void setName(String n) {
        this.name = n;
    }

    public void setAddress(String add) {
        this.address = add;
    }

    public void setPhoneNumber(String phn) {
        this.phoneNumber = phn;
    }

    //accessor
    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }
}
