/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vehicleregistrationmenu;

/**
 *
 * @author Jetsu
 */
public class PrivateOwner extends Owner {

    private int id;
    private String dateofBirth;

    public PrivateOwner(String n, String add, String phn, String dob, int i) {
        // Call the superclass constructor,
        // passing the name,address and phoneNumber as arguments.
        super(n, add, phn);

        // Set id and dateofBirth.
        this.id = i;
        this.dateofBirth = dob;
    }
    //mutator

    public void setID(int i) {
        this.id = id;
    }

    public void setDateofBirth(String dob) {
        this.dateofBirth = dob;
    }

    //accessor
    public int getId() {
        return id;
    }

    public String getDateofBirth() {
        return dateofBirth;
    }

}
