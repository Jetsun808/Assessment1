/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vehicleregistrationmenu;

/**
 *
 * @author Jetsu
 */
public class Vehicle {

    private String plateNumber;
    private String make;
    private String model;
    private int year;
    private boolean isPrivate;
    private int ownerId;
    private int ownerABN;

    /**
     * Constructor
     *
     * @param pln
     * @param mk
     * @param m
     * @param y
     * @param isp
     * @param oid
     * @param oab
     */
    public Vehicle(String pln, String mk, String m, int y, boolean isp, int oid, int oab) {
        this.plateNumber = pln;
        this.make = mk;
        this.model = m;
        this.year = y;
        this.isPrivate = isp;
        this.ownerId = oid;
        this.ownerABN = oab;
    }

    //mutator
    public void setPlateNumber(String pln) {
        this.plateNumber = pln;
    }

    public void setMake(String mk) {
        this.make = mk;
    }

    public void setModel(String m) {
        this.model = m;
    }

    public void setYear(int y) {
        this.year = y;
    }

    public void setIsPrivate(boolean isp) {
        this.isPrivate = isp;
    }

    public void setOwnerId(int oid) {
        this.ownerId = oid;
    }

    public void setOwnerABN(int oab) {
        this.ownerABN = oab;
    }

    //accessor
    public String getPlateNumber() {
        return plateNumber;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public int getYear() {
        return year;
    }

    public boolean getIsPrivate() {
        return isPrivate;
    }

    public int getOwnerId() {
        return ownerId;
    }

    public int getOwnerABN() {
        return ownerABN;
    }

}
