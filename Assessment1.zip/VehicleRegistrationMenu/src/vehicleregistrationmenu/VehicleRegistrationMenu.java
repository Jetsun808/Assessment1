/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vehicleregistrationmenu;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Jetsun
 */
public class VehicleRegistrationMenu {

    final int ENTER_OWNER = 1;
    final int ENTER_VEHICLE = 2;
    final int SEARCH_OWNER = 3;
    final int SEARCH_VEHICLE = 4;
    final int EXIT = 5;

    
    //Declaring the ArrayList for Owner objects and Vehicle objects
    ArrayList<Owner> OwnerArray = new ArrayList<>();
    ArrayList<Vehicle> VehicleArray = new ArrayList<>();

    private boolean isStringNumeric(String str) {
        for (int i = 0; i < str.length(); i++) {
            if (!Character.isDigit(str.charAt(i))) {
                return false;
            }
        }

        return true;
    }

    private int getMenuItem() {

        Scanner inputMenuChoice = new Scanner(System.in);
        System.out.println("\nPlease select from the following :");
        System.out.println(ENTER_OWNER + ". Enter owner details");
        System.out.println(ENTER_VEHICLE + ". Enter vehicle details");
        System.out.println(SEARCH_OWNER + ". Search owner");
        System.out.println(SEARCH_VEHICLE + ". Search vehicle");
        System.out.println(EXIT + ". Exit the application");
        System.out.print("\nEnter choice ==> ");

        String choice = inputMenuChoice.nextLine();

        while (choice.equals("") || !isStringNumeric(choice)) {
            System.out.println("Error - Menu selection name cannot be left blank and must be of numeric value!!!");
            System.out.print("Enter choice ==> ");

            choice = inputMenuChoice.nextLine();
        }
        return Integer.parseInt(choice);
    }

    private void processOrders() {

        int choice = getMenuItem();

        while (choice != EXIT) {
            switch (choice) {
                case ENTER_OWNER ->
                    enterOwnerRecord();
                case ENTER_VEHICLE ->
                    enterVehicleRecord();
                case SEARCH_OWNER ->
                    searchOwner();
                case SEARCH_VEHICLE ->
                    searchVehicle();
                default ->
                    System.out.println("ERROR choice not recognised!!!");
            }

            choice = getMenuItem();
        }

        System.out.println("""                          
                           Thank you for using the app.
                           !!!Have a great day!!!.
                            ٩(◕‿◕)۶
                           """);

    }

    private void enterOwnerRecord() {
        Scanner input = new Scanner(System.in);
        // Getting the owner type
        System.out.println("\nEnter the owner's vehicle type(Private/Corporate) : ");
        String type = input.nextLine();
        while (type.equals("")) {
            System.out.println("Error - field cannot be left blank!!!");
            System.out.println("\nEnter the owner's vehicle type(Private/Corporate) : ");
            type = input.nextLine();
        }
        //Getting the owner's ID and date of birth.
        //Checking if the owner with that ID already exists if the owner is private
        String id = null;
        String dateofBirth = null;
        String ownerABN = null;
        if (type.equals("Private")) {
            System.out.println("\nEnter the owner's id : ");
            id = input.nextLine();
            while (id.equals("") || !isStringNumeric(id)) {
                System.out.println("Error - field cannot be left blank and must be of numeric value!!!");
                System.out.println("\nEnter the 0wner's id : ");
                id = input.nextLine();
            }
            for (Owner o : OwnerArray) {
                if (o instanceof PrivateOwner privateOwner) {
                    if (privateOwner.getId() == Integer.parseInt(id)) {
                        System.out.println("The ID already exists!!!");
                        return;
                    }
                }
            }
            System.out.println("\nEnter the owner's date of birth  : ");
            dateofBirth = input.nextLine();
            while (dateofBirth.equals("")) {
                System.out.println("Error - field cannot be left blank!!!");
                System.out.println("\nEnter the owner's date of birth  : ");
                dateofBirth = input.nextLine();
            }
        } //Getting the owner's ABN. 
        // Checking if the owner with that ABN already exists if the owner is corporate 
        else if (type.equals("Corporate")) {
            System.out.println("\nEnter the owner's ABN : ");
            ownerABN = input.nextLine();
            while (ownerABN.equals("") || !isStringNumeric(ownerABN)) {
                System.out.println("Error - field cannot be left blank and must be of numeric value!!!");
                System.out.println("\nEnter the owner's ABN : ");
                ownerABN = input.nextLine();
            }
            for (Owner o : OwnerArray) {
                if (o instanceof CorporateOwner corporateOwner) {
                    if (corporateOwner.getABN() == Integer.parseInt(ownerABN)) {
                        System.out.println(" The ABN already exists!!!");
                        return;
                    }
                }
            }
        } else {
            System.out.println("\nSorry, wrong input");
            return;
        }
        //Getting name, address and phone number
        System.out.println("\nEnter the owner's name  : ");
        String name = input.nextLine();
        while (name.equals("")) {
            System.out.println("Error - field cannot be left blank!!!");
            System.out.println("\nEnter the owner's name  : ");
            name = input.nextLine();
        }
        System.out.println("\nEnter the owner's address  : ");
        String address = input.nextLine();
        while (address.equals("")) {
            System.out.println("Error - field cannot be left blank!!!");
            System.out.println("\nEnter the owner's address  : ");
            address = input.nextLine();
        }
        System.out.println("\nEnter the owner's phone number  : ");
        String phoneNumber = input.nextLine();
        while (phoneNumber.equals("")) {
            System.out.println("Error - field cannot be left blank!!!");
            System.out.println("\nEnter the owner's phone number  : ");
            phoneNumber = input.nextLine();
        }
        //On the contrary of the owner type; creating an object of the relevant owner class, appending the object to the owner ArrayList and printing the owner info in the console 
        if (type.equals("Private")) {
            PrivateOwner p;
            p = new PrivateOwner(name, address, phoneNumber, dateofBirth, Integer.parseInt(id));
            OwnerArray.add(p);
            System.out.println("Name of the Owner : " + p.getName());
            System.out.println("ID number : " + p.getId());
            System.out.println("Adddress : " + p.getAddress());
            System.out.println("Date of Birth : " + p.getDateofBirth());
            System.out.println("Phone Number : " + p.getPhoneNumber());
        } else {
            CorporateOwner p = new CorporateOwner(name, address, phoneNumber, Integer.parseInt(ownerABN));
            OwnerArray.add(p);
            System.out.println("Name of the Owner : " + p.getName());
            System.out.println("ABN number : " + p.getABN());
            System.out.println("Adddress : " + p.getAddress());
            System.out.println("Phone Number : " + p.getPhoneNumber());
        }
    }

    private void enterVehicleRecord() {
        {
            
            Scanner input = new Scanner(System.in);
            // Getting the plate number.
            // Checking if the vehicle with that plate number already exists
            String plateNumber = null;
            System.out.println("\nEnter the plate number : ");
            plateNumber = input.nextLine();
            while (plateNumber.equals("")) {
                System.out.println("Error - field cannot be left blank!!!");
                System.out.println("\nEnter the plate number : ");
                plateNumber = input.nextLine();
            }
            for (Vehicle o : VehicleArray) {
                if (o.getPlateNumber().equals(plateNumber)) {
                    System.out.println(" The Plate Number already exists!!!");
                    return;
                }
            }
            // Getting the vehicle type
            String type = null;
            System.out.println("\nEnter the type of vehicle(Heavy/Light) : ");
            type = input.nextLine();
            while (type.equals("")) {
                System.out.println("Error - field cannot be left blank!!!");
                System.out.println("\nEnter the type of vehicle(Heavy/Light) : ");
                type = input.nextLine();
            }
            String loadCapacity = null, numberOfseats = null;
            // Getting the load capacity if the vehicle is heavy
            if (type.equals("Heavy")) {
                System.out.println("\nEnter the load capacity : ");
                loadCapacity = input.nextLine();
                while (loadCapacity.equals("") || !isStringNumeric(loadCapacity)) {
                    System.out.println("Error - field cannot be left blank and must be of numeric value!!!");
                    System.out.println("\nEnter the load capacity : ");
                    loadCapacity = input.nextLine();
                }
            } // Getting the number of seats if the owner is light 
            else if (type.equals("Light")) {
                System.out.println("\nEnter the number of seats : ");
                numberOfseats = input.nextLine();
                while (numberOfseats.equals("") || !isStringNumeric(numberOfseats)) {
                    System.out.println("Error - field cannot be left blank and must be of numeric value!!!");
                    System.out.println("\nEnter the number of seats : ");
                    numberOfseats = input.nextLine();
                }
            }
            // Getting the make, model, and year
            String make = null, model = null, year = null, vehicleownerType = null;
            System.out.println("\nEnter the make : ");
            make = input.nextLine();
            while (make.equals("")) {
                System.out.println("Error - field cannot be left blank!!!");
                System.out.println("\nEnter the make : ");
                make = input.nextLine();
            }
            System.out.println("\nEnter the model : ");
            model = input.nextLine();
            while (model.equals("")) {
                System.out.println("Error - field cannot be left blank!!!");
                System.out.println("\nEnter the model : ");
                model = input.nextLine();
            }
            System.out.println("\nEnter the year : ");
            year = input.nextLine();
            while (year.equals("")|| !isStringNumeric(year)) {
                System.out.println("Error - field cannot be left blank and must be of numeric value!!!");
                System.out.println("\nEnter year : ");
                year = input.nextLine();
            }
            // Getting the vehicle owner type. 
            System.out.println("\nEnter the vehicle owner type(Private/Corporate) : ");
            vehicleownerType = input.nextLine();
            while (vehicleownerType.equals("")) {
                System.out.println("Error - field cannot be left blank!!!");
                System.out.println("\nEnter the vehicle owner type(Private/Corporate) : ");
                vehicleownerType = input.nextLine();
            }
            // Getting the owner's ID or ABN depending on the owner type. Checking if the  owner with that ID or ABN exists
            String ownerABN = null;
            String ownerId = null;
            boolean isPresent = false;
            if (vehicleownerType.equals("Private")) {
                System.out.println("\nEnter the owner's id : ");
                ownerId = input.nextLine();
                while (ownerId.equals("") || !isStringNumeric(ownerId)) {
                    System.out.println("Error - field cannot be left blank and must be numeric value!!!");
                    System.out.println("\nEnter the owner's id : ");
                    ownerId = input.nextLine();
                }
                for (Owner o : OwnerArray) {
                    if (o instanceof PrivateOwner privateOwner) {
                        if (privateOwner.getId() == Integer.parseInt(ownerId)) {
                            isPresent = true;
                        }
                    }
                }
            } else if (vehicleownerType.equals("Corporate")) {
                System.out.println("\nEnter the owner's ABN : ");
                ownerABN = input.nextLine();
                while (ownerABN.equals("") || !isStringNumeric(ownerABN)) {
                    System.out.println("Error - field cannot be left blank and must be numeric value!!!");
                    System.out.println("\nEnter the owner's ABN : ");
                    ownerABN = input.nextLine();
                }
                for (Owner o : OwnerArray) {
                    if (o instanceof CorporateOwner corporateOwner) {
                        if (corporateOwner.getABN() == Integer.parseInt(ownerABN)) {
                            isPresent = true;
                        }
                    }
                }
            } else {
                System.out.println("\nSorry, wrong input");
                return;
            }
            // Printing an error message and exit if the owner with that ID or ABN doesn't exist
            if (!isPresent) {
                System.out.println("\n An Error has occured!!!");
                return;
            }
            // Depending on the vehicle type, create an object of the relevant vehicle class, append the object to the vehicle ArrayList 
            // and print the owner info in the console
            if (ownerABN == null) {
                ownerABN = "-1";
            }
            if (ownerId == null) {
                ownerId = "-1";
            }
            if (type.equals("Heavy")) {
                HeavyVehicle h = new HeavyVehicle(plateNumber, make, model, Integer.parseInt(year), vehicleownerType.equals("Private"), Integer.parseInt(ownerId), Integer.parseInt(ownerABN), Integer.parseInt(loadCapacity));
                VehicleArray.add(h);
                System.out.println("Plate Number of Vehicle : " + h.getPlateNumber());
                System.out.println("Maker of Vehicle : " + h.getMake());
                System.out.println("Model of Vehicle : " + h.getModel());
                System.out.println("Current Year : " + h.getYear());
                System.out.println("Owner is Private or Not : " + h.getIsPrivate());
                if (h.getOwnerId() != -1) {
                    System.out.println("ID Number : " + h.getOwnerId());
                }
                if (h.getOwnerABN() != -1) {
                    System.out.println("ABN Number : " + h.getOwnerABN());
                }
                System.out.println(" The load capacity of the vehicle : " + h.getLoadCapacity());
            } else {
                LightVehicle h = new LightVehicle(plateNumber, make, model, Integer.parseInt(year), vehicleownerType.equals("Private"), Integer.parseInt(ownerId), Integer.parseInt(ownerABN), Integer.parseInt(numberOfseats));
                VehicleArray.add(h);
                System.out.println("Plate Number of Vehicle : " + h.getPlateNumber());
                System.out.println("Maker of Vehicle : " + h.getMake());
                System.out.println("Model of Vehicle : " + h.getModel());
                System.out.println("Current Year : " + h.getYear());
                System.out.println("Owner is Private or Not : " + h.getIsPrivate());
                if (h.getOwnerId() != -1) {
                    System.out.println("ID Number : " + h.getOwnerId());
                }
                if (h.getOwnerABN() != -1) {
                    System.out.println("ABN Number : " + h.getOwnerABN());
                }
                System.out.println("Number of seats in the vehicle : " + h.getNumberofSeats());
            }

        }
    }

    private void searchOwner() {
        // TODO
        Scanner input = new Scanner(System.in);
        // Get owner type
        System.out.println("\nEnter Owner Type(Private/Corporate) : ");
        String type = input.nextLine();
        while (type.equals("")) {
            System.out.println("Error - field cannot be blank!!!");
            System.out.println("\nEnter Owner Type(Private/Corporate) : ");
            type = input.nextLine();
        }
        // If the owner is private, get owner ID and date of birth. Check if a owner with that ID already exists
        String id = null;
        String ownerABN = null;
        boolean isPresent = false;
        // Get the onwer ID or ABN depending on the type
        // Check each element of the owner ArrayList to find a match for that owner ID or ABN   
        // If a matching owner is found, then print the owner info in the console 
        if (type.equals("Private")) {
            System.out.println("\nEnter the owner's id : ");
            id = input.nextLine();
            while (id.equals("") || !isStringNumeric(id)) {
                System.out.println("Error - field cannot be left blank and must be of numeric value!!!");
                System.out.println("\nEnter the owner's id : ");
                id = input.nextLine();
            }
            for (Owner o : OwnerArray) {
                if (o instanceof PrivateOwner privateOwner) {
                    if (privateOwner.getId() == Integer.parseInt(id)) {
                        System.out.println("Name of the owner : " + o.getName());
                        System.out.println("ID number : " + privateOwner.getId());
                        System.out.println("Address : " + o.getAddress());
                        System.out.println("Date of Birth : " + privateOwner.getDateofBirth());
                        System.out.println("Phone Number : " + o.getPhoneNumber());
                        isPresent = true;
                    }
                }
            }
        } else if (type.equals("Corporate")) {
            System.out.println("\nEnter the owner's ABN : ");
            ownerABN = input.nextLine();
            while (ownerABN.equals("") || !isStringNumeric(ownerABN)) {
                System.out.println("Error - field cannot be left blank and must be of numeric value!!!");
                System.out.println("\nEnter the owner's ABN : ");
                ownerABN = input.nextLine();
            }
            for (Owner o : OwnerArray) {
                if (o instanceof CorporateOwner corporateOwner) {
                    if (corporateOwner.getABN() == Integer.parseInt(ownerABN)) {
                        System.out.println("Name of the Owner : " + o.getName());
                        System.out.println("ABN number : " + corporateOwner.getABN());
                        System.out.println("Adddress : " + o.getAddress());
                        System.out.println("Phone Number : " + o.getPhoneNumber());
                        isPresent = true;
                    }
                }
            }
        } else {
            System.out.println("\nSorry, wrong input");
            return;
        }
        // If there is no match, print 'No record found' and exit
        if (!isPresent) {
            System.out.println("\nNo record found");
        }
    }

    private void searchVehicle() {
        // TODO
        Scanner input = new Scanner(System.in);
        String plateNumber = null;
        System.out.println("\nEnter the plate number of the vehicle : ");
        plateNumber = input.nextLine();
        while (plateNumber.equals("")) {
            System.out.println("Error - field cannot be left blank!!!");
            System.out.println("\nEnter the plate number of the vehicle : ");
            plateNumber = input.nextLine();
        }
        boolean isPresent = false;
        // Check each element of the vehicle ArrayList to find a match for that plate number   
        for (Vehicle o : VehicleArray) {
            // If a matching vehicle is found, then print the vehicle info in the console  
            if (o.getPlateNumber().equals(plateNumber)) {
                System.out.println("Plate number of the vehicle : " + o.getPlateNumber());
                System.out.println("Maker of the vehicle : " + o.getMake());
                System.out.println("Model of the vehicle : " + o.getModel());
                System.out.println("Current Year : " + o.getYear());
                System.out.println("Owner is Private or Not : " + o.getIsPrivate());
                if (o.getOwnerId() != -1) {
                    System.out.println("ID Number : " + o.getOwnerId());
                }
                if (o.getOwnerABN() != -1) {
                    System.out.println("ABN Number : " + o.getOwnerABN());
                }
                if (o instanceof HeavyVehicle heavyVehicle) {
                    System.out.println("The load capacity of the vehicle : " + heavyVehicle.getLoadCapacity());
                } else {
                    System.out.println("The number of seats in the vehicle : " + ((LightVehicle) o).getNumberofSeats());
                }
                isPresent = true;
            }
        }
        // If there is no match, print 'No record found' and exit
        if (!isPresent) {
            System.out.println("\nNo record found");
        }

    }

    public static void main(String[] args) {

        VehicleRegistrationMenu app = new VehicleRegistrationMenu();
        System.out.println("""
                           Welcome to the Vehicel Registration app.
                           (づ ◕‿◕ )づ
                                                     
                           You are currently in the menu section.
                           """);
        app.processOrders();
    }

}
